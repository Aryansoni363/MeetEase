// src/socket/index.js

import { Server } from "socket.io";
import jwt from "jsonwebtoken";
import { Meeting } from "../models/meeting.models.js";

const JWT_SECRET = process.env.ACCESS_TOKEN_SECRET;

export default function initializeSocket(server) {
  const io = new Server(server, {
    cors: {
      origin: process.env.CORS_ORIGIN
        ? process.env.CORS_ORIGIN.split(",")
        : "*",
      methods: ["GET", "POST"],
      credentials: true,
    },
    transports: ["websocket"],
  });

  // ─── 1) Authenticate socket handshake ──────────────────────────────────
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (!token) {
      return next(new Error("Authentication error"));
    }

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
      if (err) {
        // Distinguish expired vs other errors
        if (err.name === "TokenExpiredError") {
          return next(new Error("TokenExpired"));
        }
        return next(new Error("Authentication error"));
      }
      socket.user = decoded; // { _id, username, ... }
      next();
    });
  });

  // ─── 2) Utility to list chat participants ──────────────────────────────
  const getChatParticipants = (room) => {
    const clients = io.sockets.adapter.rooms.get(room) || new Set();
    return Array.from(clients).map((socketId) => {
      const s = io.sockets.sockets.get(socketId);
      return { userId: s.user._id };
    });
  };

  // ─── 3) Track WebRTC rooms ────────────────────────────────────────────
  const webrtcRooms = {}; // roomId → Set<socket.id>

  io.on("connection", (socket) => {
    console.log(`✅ WS connected: ${socket.id} (user ${socket.user._id})`);

    // ── CHAT: join-room ───────────────────────────────────────────────
    socket.on("join-room", ({ room }) => {
      socket.join(room);
      io.in(room).emit("room:participants", {
        participants: getChatParticipants(room),
      });
    });

    // ── CHAT: send-message ──────────────────────────────────────────
    socket.on("send-message", async ({ room, text }) => {
      const msg = { senderId: socket.user._id, text, timestamp: new Date() };
      io.in(room).emit("receive-message", msg);
      try {
        const meeting = await Meeting.findOne({ roomId: room });
        if (meeting) {
          meeting.messages.push(msg);
          await meeting.save();
        }
      } catch (e) {
        console.error("❌ Failed to save chat message:", e);
      }
    });

    // ── CHAT: leave-room ───────────────────────────────────────────
    socket.on("leave-room", ({ room }) => {
      socket.leave(room);
      io.in(room).emit("room:participants", {
        participants: getChatParticipants(room),
      });
    });

    // ── WEBRTC: join-webrtc-room ──────────────────────────────────
    socket.on("join-webrtc-room", ({ room }) => {
      socket.join(room);
      webrtcRooms[room] = webrtcRooms[room] || new Set();
      webrtcRooms[room].add(socket.id);
      const others = Array.from(webrtcRooms[room]).filter(id => id !== socket.id);
      socket.emit("all-users", others);
    });

    // ── WEBRTC: signaling ───────────────────────────────────────
    socket.on("webrtc-offer", ({ to, offer }) => {
      io.to(to).emit("webrtc-offer", { from: socket.id, offer });
    });
    socket.on("webrtc-answer", ({ to, answer }) => {
      io.to(to).emit("webrtc-answer", { from: socket.id, answer });
    });
    socket.on("webrtc-ice-candidate", ({ to, candidate }) => {
      io.to(to).emit("webrtc-ice-candidate", { from: socket.id, candidate });
    });

    // ── CLEANUP on disconnect ─────────────────────────────────────
    socket.on("disconnect", () => {
      console.log(`❌ WS disconnected: ${socket.id}`);
      Object.values(webrtcRooms).forEach(set => set.delete(socket.id));
      for (const room of socket.rooms) {
        socket.to(room).emit("user:left-webrtc", { userId: socket.id });
      }
    });
  });

  // ─── Global error logging ───────────────────────────────────────────
  io.on("connect_error", (err) => {
    console.error("⚠️ Socket.IO error:", err.message);
  });

  return io;
}
