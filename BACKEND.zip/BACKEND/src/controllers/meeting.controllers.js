// src/controllers/meeting.controllers.js

import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError }       from "../utils/ApiError.js";
import { ApiResponse }    from "../utils/ApiResponse.js";
import { Meeting }        from "../models/meeting.models.js";
import { User }           from "../models/user.models.js";
import { v4 as uuidv4 }   from "uuid";
import crypto             from "crypto";

// —————— Helper: Secure 8-char alphanumeric code —————————
const generateMeetingCode = () => {
  return crypto
    .randomBytes(6)               // 6 random bytes
    .toString("base64")           // convert to base64
    .replace(/[^a-zA-Z0-9]/g, "") // strip non-alphanumerics
    .substring(0, 8);             // take first 8 chars
};





// New controller to resolve roomId from meetingCode
export const getRoomIdFromMeetingCode = asyncHandler(async (req, res) => {
  const { meetingCode } = req.params;
  const meeting = await Meeting.findOne({ meetingCode });

  if (!meeting) {
    throw new ApiError(404, 'Meeting not found');
  }

  return res.status(200).json(
    new ApiResponse(200, { roomId: meeting.roomId }, 'RoomId fetched successfully')
  );
});

// —————— CREATE MEETING —————————————————————————————
const createMeeting = asyncHandler(async (req, res) => {
  const { startTime } = req.body;
  if (!startTime) throw new ApiError(400, "Start time is required");

  const roomId      = uuidv4();
  const meetingCode = generateMeetingCode();

  const meeting = await Meeting.create({
    roomId,
    meetingCode,              // ← now stored in DB
    host: req.user._id,
    participants: [{
      user: req.user._id,
      joinTime: new Date(startTime)
    }],
    startTime: new Date(startTime)
  });

  // record in user’s history
  await User.findByIdAndUpdate(
    req.user._id,
    { $push: { meetingHistory: { meetingId: meeting._id } } },
    { new: true }
  );

  return res.status(201).json(
    new ApiResponse(201, {
      roomId:      meeting.roomId,
      meetingCode: meeting.meetingCode,
      meetingURL:  `${process.env.FRONTEND_BASE_URL}/meet/${meeting.meetingCode}`
    }, "Meeting created successfully")
  );
});

// —————— JOIN MEETING —————————————————————————————————
const joinMeeting = asyncHandler(async (req, res) => {
  const { meetingCode, userId } = req.body;

  // Find meeting by meetingCode, NOT roomId
  const meeting = await Meeting.findOne({ meetingCode });

  if (!meeting) {
    throw new ApiError(404, "Meeting not found");
  }

  // Check if user is already a participant
  const already = meeting.participants.some(p =>
    p.user.toString() === userId.toString()
  );

  // If not already, add participant
  if (!already) {
    meeting.participants.push({ user: userId, joinTime: new Date() });
    await meeting.save();

    await User.findByIdAndUpdate(
      userId,
      { $push: { meetingHistory: { meetingId: meeting._id } } },
      { new: true }
    );
  }

  return res.status(200).json(
    new ApiResponse(200, {
      roomId: meeting.roomId,
      meetingCode: meeting.meetingCode,
      meetingURL: `https://meetease.com/meet/${meeting.meetingCode}`,
      participants: meeting.participants
    }, "Joined meeting successfully")
  );
});

// —————— LEAVE MEETING ——————————————————————————————
const leaveMeeting = asyncHandler(async (req, res) => {
  const { roomId } = req.params;
  const meeting    = await Meeting.findOne({ roomId });
  if (!meeting) throw new ApiError(404, "Meeting not found");

  meeting.participants = meeting.participants.filter(
    p => p.user.toString() !== req.user._id.toString()
  );
  await meeting.save();

  return res.status(200).json(
    new ApiResponse(200, { roomId }, "Left meeting successfully")
  );
});

// —————— GET MEETING HISTORY ——————————————————————————
const getMeetingHistory = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id)
    .populate({
      path: "meetingHistory.meetingId",
      select: "roomId meetingCode startTime endTime createdAt"
    })
    .select("meetingHistory");

  if (!user) throw new ApiError(404, "User not found");

  return res.status(200).json(
    new ApiResponse(200, user.meetingHistory, "Fetched meeting history")
  );
});

// —————— POST MESSAGE —————————————————————————————
const postMessage = asyncHandler(async (req, res) => {
  const { roomId } = req.params;
  const { text }   = req.body;
  if (!text?.trim()) throw new ApiError(400, "Message text is required");

  const meeting = await Meeting.findOne({ roomId });
  if (!meeting) throw new ApiError(404, "Meeting not found");

  const message = {
    sender: req.user._id,
    text,
    timestamp: new Date(),
  };
  meeting.messages.push(message);
  await meeting.save();

  return res.status(201).json(new ApiResponse(201, message, "Message posted"));
});

// —————— GET MESSAGES ——————————————————————————————
const getMessages = asyncHandler(async (req, res) => {
  const { roomId } = req.params;
  const meeting    = await Meeting.findOne({ roomId })
    .populate("messages.sender", "username");
  if (!meeting) throw new ApiError(404, "Meeting not found");

  return res.json(new ApiResponse(200, meeting.messages, "Messages fetched"));
});

export {
  createMeeting,
  joinMeeting,
  leaveMeeting,
  getMeetingHistory,
  postMessage,
  getMessages,
  
};
